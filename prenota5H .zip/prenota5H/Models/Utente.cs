namespace prenota5H.Models;

public class Utente
{
    public string? Nome { get; set; }

    public string? Cognome { get; set; }

    public string? Tipo { get; set; }
    
    public string? Email { get; set; }

    
}